package kz.bitlab.springboot.sprinttask1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sprinttask1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
